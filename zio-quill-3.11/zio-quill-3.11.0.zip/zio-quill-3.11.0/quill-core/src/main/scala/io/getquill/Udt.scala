package io.getquill

trait Udt
