package io.getquill.context.jasync

package object postgres {
  object testContext extends TestContext
}
