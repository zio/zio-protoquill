package io.getquill.context.jasync

package object mysql {
  object testContext extends TestContext
}
