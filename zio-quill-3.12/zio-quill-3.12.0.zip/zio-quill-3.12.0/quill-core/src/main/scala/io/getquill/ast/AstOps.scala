package io.getquill.ast

object AstOps {

}
