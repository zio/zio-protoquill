package io.getquill

trait Embedded
