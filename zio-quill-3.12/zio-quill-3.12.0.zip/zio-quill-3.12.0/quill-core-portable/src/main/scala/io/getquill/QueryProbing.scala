package io.getquill

trait QueryProbing
